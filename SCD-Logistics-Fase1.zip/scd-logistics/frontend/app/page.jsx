"use client";
import { useEffect, useState } from "react";
import { getProductos, importar, getRevisiones } from "../lib/api";

const NAV = [["maestro","Maestro"],["importar","Importar"],["revision","Revisión"],["historial","Historial"]];

function Badge({ estado }) {
  const map = { "correcto":"b-ok", "corregido":"b-fix", "sin dimensiones":"b-none",
                "pendiente de revision":"b-none" };
  return <span className={"badge " + (map[estado] || "b-none")}>{estado || "—"}</span>;
}

export default function Home() {
  const [tab, setTab] = useState("maestro");
  return (
    <div className="app">
      <aside className="side">
        <div className="brand">SCD Logistics</div>
        <nav className="nav">
          {NAV.map(([k, label]) => (
            <button key={k} className={tab===k?"active":""} onClick={()=>setTab(k)}>{label}</button>
          ))}
        </nav>
      </aside>
      <main className="main">
        {tab==="maestro"   && <Maestro/>}
        {tab==="importar"  && <Importar/>}
        {tab==="revision"  && <Revision/>}
        {tab==="historial" && <Historial/>}
      </main>
    </div>
  );
}

function Maestro() {
  const [rows,setRows]=useState([]); const [q,setQ]=useState(""); const [err,setErr]=useState("");
  useEffect(()=>{ getProductos(q).then(setRows).catch(e=>setErr(e.message)); }, [q]);
  return (<>
    <h1>Maestro de dimensiones</h1>
    <p className="sub">Base única de productos y medidas de embalaje.</p>
    <div style={{display:"flex",gap:12,marginBottom:16,alignItems:"center"}}>
      <input type="search" placeholder="Buscar por SKU o descripción…" value={q} onChange={e=>setQ(e.target.value)}/>
      <span style={{color:"var(--muted)",fontSize:13}}>{rows.length} productos</span>
    </div>
    {err && <div className="card" style={{color:"var(--warn)"}}>{err}</div>}
    <div className="card" style={{padding:0,overflow:"hidden"}}>
      <table><thead><tr>
        <th>SKU</th><th>Descripción</th><th>L×A×H (m)</th><th>Vol. m³</th><th>Tipo</th><th>Volumen</th>
      </tr></thead><tbody>
        {rows.map((p,i)=>(<tr key={i}>
          <td style={{fontWeight:500}}>{p.sku}</td>
          <td style={{color:"var(--muted)"}}>{p.descripcion}</td>
          <td>{[p.largo_m,p.ancho_m,p.alto_m].filter(x=>x!=null).join(" × ")||"—"}</td>
          <td>{p.volumen_calculado_m3 ?? "—"}</td>
          <td>{p.tipo==="set" ? <span className="badge b-fix">set</span> : "normal"}</td>
          <td><Badge estado={p.estado_volumen}/></td>
        </tr>))}
      </tbody></table>
    </div>
  </>);
}

function Importar() {
  const [res,setRes]=useState(null); const [busy,setBusy]=useState(false); const [name,setName]=useState("");
  async function handle(file){ if(!file)return; setName(file.name); setBusy(true);
    try{ setRes(await importar(file,false)); } finally{ setBusy(false); } }
  return (<>
    <h1>Importar packing list</h1>
    <p className="sub">Arrastrá o elegí un archivo PDF, XLSX o CSV. Primero te muestro un resumen; nada se guarda sin tu confirmación.</p>
    <label className="drop">
      <input type="file" accept=".pdf,.xlsx,.xls,.csv" style={{display:"none"}}
        onChange={e=>handle(e.target.files[0])}/>
      {busy ? "Procesando…" : (name || "Hacé clic o soltá el archivo acá")}
    </label>
    {res && <div className="card" style={{marginTop:16}}>
      {res.errores?.length>0 && <p style={{color:"var(--warn)"}}>{res.errores.join(" · ")}</p>}
      <div className="grid3">
        <div className="metric">{res.detectados}<span>detectados</span></div>
        <div className="metric">{res.nuevos}<span>nuevos</span></div>
        <div className="metric">{res.existentes}<span>ya existentes</span></div>
        <div className="metric">{res.modificados}<span>modificados</span></div>
        <div className="metric">{res.duplicados_en_archivo}<span>duplicados en archivo</span></div>
        <div className="metric">{res.no_interpretadas}<span>filas no interpretadas</span></div>
      </div>
    </div>}
  </>);
}

function Revision() {
  const [rows,setRows]=useState([]);
  useEffect(()=>{ getRevisiones().then(setRows).catch(()=>{}); }, []);
  return (<>
    <h1>Revisión</h1>
    <p className="sub">Productos con dimensiones diferentes o faltantes. Nada se sobrescribe automáticamente.</p>
    {rows.length===0 && <div className="card" style={{color:"var(--muted)"}}>No hay nada pendiente de revisión.</div>}
    {rows.map((r,i)=>(<div className="card" key={i}>
      <b>{r.sku}</b> — {r.motivo}
      <div style={{display:"flex",gap:24,margin:"12px 0",fontSize:14}}>
        <div><div style={{color:"var(--muted)"}}>Actual</div><code>{JSON.stringify(r.valores_actuales_json)}</code></div>
        <div><div style={{color:"var(--muted)"}}>Nuevo</div><code>{JSON.stringify(r.valores_nuevos_json)}</code></div>
      </div>
      <div style={{display:"flex",gap:8}}>
        <button className="btn secondary">Mantener actual</button>
        <button className="btn secondary">Guardar como variante</button>
        <button className="btn">Actualizar</button>
      </div>
    </div>))}
  </>);
}

function Historial() {
  return (<>
    <h1>Historial</h1>
    <p className="sub">Cada archivo procesado queda registrado con su fecha, origen y resumen.</p>
    <div className="card" style={{color:"var(--muted)"}}>El historial se completa a medida que importás archivos.</div>
  </>);
}
