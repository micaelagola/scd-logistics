import "./globals.css";
export const metadata = { title: "SCD Logistics", description: "Maestro de dimensiones" };
export default function RootLayout({ children }) {
  return (<html lang="es"><body>{children}</body></html>);
}
