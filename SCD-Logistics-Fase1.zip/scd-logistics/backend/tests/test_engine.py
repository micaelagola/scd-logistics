import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app.engine.sku import normalize_sku, is_set
from app.engine.volume import sanitize_volume
from app.engine.dedup import classify

def test_sku_rule():
    assert normalize_sku("WT-GT350") == "GT350"
    assert normalize_sku("WT-CHD65-BL + SBS22") == "CHD65-BL + SBS22"
    assert normalize_sku("KX-100") == "KX-100"
    assert normalize_sku("ABC-20-BL") == "ABC-20-BL"
    assert normalize_sku("GT350") == "GT350"
    assert normalize_sku("UT202A+") == "UT202A+"      # sufijo intacto
    assert normalize_sku("  WT-TMS ") == "TMS"         # solo trim externo
    assert normalize_sku("wt-abc") == "wt-abc"         # case-sensitive: no toca

def test_sets():
    assert is_set("WT-CHD65-BL + SBS22", "IMPACT DRILL and bits set") is True
    assert is_set("CHT15-BL\nCCS6-BL\nIn one set", "HEDGE TRIMMER") is True
    assert is_set("UT202A+", "DIGITAL CLAMP") is False       # sufijo, no set
    assert is_set("TMS", "TAP AND DIE SET") is False          # producto unico

def test_volume():
    assert sanitize_volume(0.8,0.24,0.265,-0.0107783)["estado_volumen"]=="corregido"   # negativo
    assert sanitize_volume(0.8,0.24,0.265,-0.0107783)["volumen_calculado_m3"]==0.05088
    assert sanitize_volume(0,0,0,0.06)["estado_volumen"]=="sin dimensiones"             # cero
    ok=sanitize_volume(0.41,0.38,0.28,0.043624); assert ok["estado_volumen"]=="correcto"
    assert sanitize_volume(0.51,0.275,0.215,0.001)["estado_volumen"]=="corregido"       # inconsistente

def test_dedup():
    master={"GT350":{"largo_m":0.8,"ancho_m":0.24,"alto_m":0.265}}
    items=[{"sku":"GT350","largo_m":0.8,"ancho_m":0.24,"alto_m":0.265},
           {"sku":"NEW1","largo_m":0.1,"ancho_m":0.1,"alto_m":0.1},
           {"sku":"GT350","largo_m":0.9,"ancho_m":0.24,"alto_m":0.265}]
    r=classify(items, master)
    assert r["existente_sin_cambios"]==["GT350"]
    assert len(r["nuevos"])==1
    assert "GT350" in r["duplicados_en_archivo"]  # 3ra fila = duplicado dentro del archivo

if __name__=="__main__":
    import traceback
    fns=[test_sku_rule,test_sets,test_volume,test_dedup]; ok=0
    for fn in fns:
        try: fn(); print("PASS",fn.__name__); ok+=1
        except Exception: print("FAIL",fn.__name__); traceback.print_exc()
    print(f"\n{ok}/{len(fns)} passed")
