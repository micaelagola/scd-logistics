"""Carga inicial del maestro saneado a Postgres/Supabase.
Uso:  DATABASE_URL=... python seed_master.py data/master_PL_SANEADO.csv
"""
import sys, csv, os, psycopg
def main(path):
    url=os.environ["DATABASE_URL"]
    with psycopg.connect(url) as c, c.cursor() as cur, open(path, encoding="utf-8") as f:
        n=0
        for r in csv.DictReader(f):
            def num(x): return float(x) if x not in (None,"","None") else None
            cur.execute("""insert into productos
              (sku,descripcion,largo_m,ancho_m,alto_m,volumen_calculado_m3,volumen_original_m3,
               estado_volumen,tipo,fuente,archivo_origen,fecha_recalculo)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
              on conflict (sku) do nothing""",
              [r["sku"],r["articulo"],num(r["largo_m"]),num(r["ancho_m"]),num(r["alto_m"]),
               num(r["volumen_calculado_m3"]),num(r["volumen_original_m3"]),r["estado_volumen"],
               r["tipo"],r["fuente"],r["archivo_origen"],r["fecha_recalculo"]])
            n+=1
        print(f"Cargados {n} productos.")
if __name__=="__main__":
    main(sys.argv[1] if len(sys.argv)>1 else "data/master_PL_SANEADO.csv")
