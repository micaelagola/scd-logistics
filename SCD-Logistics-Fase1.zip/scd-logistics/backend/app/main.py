"""SCD Logistics API (Fase 1 — Maestro de dimensiones).
Todo el acceso a datos y credenciales vive acá (server-side). El frontend
solo consume estos endpoints.
"""
import io, os
from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import openpyxl

from .engine.sku import normalize_sku
from .engine.volume import sanitize_volume
from .engine.importer import parse_rows, parse_pdf_text
from .engine.dedup import classify
from . import db

app = FastAPI(title="SCD Logistics API", version="1.0")

origins = os.environ.get("FRONTEND_ORIGIN", "*").split(",")
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"],
                   allow_headers=["*"])

MAX_MB = 25

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/productos")
def productos(q: str | None = Query(default=None)):
    return db.list_productos(q)

def _rows_from_upload(name, content):
    ext = name.lower().rsplit(".", 1)[-1]
    if ext in ("xlsx", "xlsm", "xls"):
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
        ws = wb[wb.sheetnames[0]]
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
        return parse_rows(rows, fuente=name, archivo=name)
    if ext == "csv":
        import csv
        rows = list(csv.reader(io.StringIO(content.decode("utf-8", "ignore"))))
        return parse_rows(rows, fuente=name, archivo=name)
    if ext == "pdf":
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            text = "\n".join((p.extract_text() or "") for p in pdf.pages)
            rows = [r for p in pdf.pages for t in (p.extract_tables() or []) for r in t]
        items, res = parse_rows(rows, fuente=name, archivo=name)  # intento tabla
        if res["detectados"] == 0:                                # fallback texto
            items, res = parse_pdf_text(text, fuente=name, archivo=name)
        return items, res
    raise HTTPException(400, "Formato no soportado. Usá PDF, XLSX o CSV.")

@app.post("/importar")
async def importar(file: UploadFile = File(...), commit: bool = False):
    content = await file.read()
    if len(content) > MAX_MB * 1024 * 1024:
        raise HTTPException(413, f"El archivo supera {MAX_MB} MB.")
    items, res = _rows_from_upload(file.filename, content)

    # recalcular volumen de lo importado si trae dims
    for it in items:
        s = sanitize_volume(it.get("largo_m"), it.get("ancho_m"), it.get("alto_m"), it.get("cbm"))
        it.update(volumen_calculado_m3=s["volumen_calculado_m3"], estado_volumen=s["estado_volumen"])

    try:
        master = db.get_by_skus([it["sku"] for it in items])
    except Exception:
        if commit:
            raise
        master = {}   # preview sin base configurada
    cls = classify(items, master)
    resumen = {
        "detectados": res["detectados"],
        "nuevos": len(cls["nuevos"]),
        "existentes": len(cls["existente_sin_cambios"]),
        "modificados": len(cls["modificados"]),
        "duplicados_en_archivo": len(cls["duplicados_en_archivo"]),
        "no_interpretadas": res["no_interpretadas"],
        "errores": res["errores"],
    }
    if commit:
        imp_id = db.registrar_importacion(file.filename, file.filename.rsplit(".",1)[-1], resumen)
        for it in cls["nuevos"]:
            db.upsert_producto(it)
        for rev in cls["revisiones"]:
            db.crear_revision(rev["sku"], imp_id, rev["valores_actuales"], rev["valores_nuevos"], rev["motivo"])
        resumen["importacion_id"] = imp_id
    return resumen

@app.get("/revisiones")
def revisiones():
    return db.list_revisiones()

@app.get("/export.xlsx")
def export():
    prods = db.list_productos()
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "maestro"
    if prods:
        cols = list(prods[0].keys()); ws.append(cols)
        for p in prods: ws.append([p[c] for c in cols])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return StreamingResponse(buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=maestro_saneado.xlsx"})
