"""Deduplicación contra el maestro. SKU normalizado = clave lógica."""
def _dims_equal(a, b, tol=1e-6):
    for k in ("largo_m", "ancho_m", "alto_m"):
        va, vb = a.get(k), b.get(k)
        if va is None or vb is None:
            if va != vb:
                return False
        elif abs(float(va) - float(vb)) > tol:
            return False
    return True

def classify(items, master_by_sku):
    """Devuelve resumen + lista de revisiones. No escribe nada."""
    out = {"nuevos": [], "existente_sin_cambios": [], "modificados": [],
           "duplicados_en_archivo": [], "revisiones": []}
    seen = set()
    for it in items:
        sku = it["sku"]
        if sku in seen:
            out["duplicados_en_archivo"].append(sku)
            continue
        seen.add(sku)
        if sku not in master_by_sku:
            out["nuevos"].append(it)
        elif _dims_equal(it, master_by_sku[sku]):
            out["existente_sin_cambios"].append(sku)
        else:
            out["modificados"].append(sku)
            out["revisiones"].append({
                "sku": sku,
                "valores_actuales": {k: master_by_sku[sku].get(k) for k in ("largo_m","ancho_m","alto_m","volumen_calculado_m3")},
                "valores_nuevos": {k: it.get(k) for k in ("largo_m","ancho_m","alto_m")},
                "archivo_origen": it.get("archivo_origen"),
                "motivo": "Encontré dimensiones diferentes",
            })
    return out
