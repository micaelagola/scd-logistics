"""Saneamiento de volúmenes. El volumen histórico NO es confiable."""
from typing import Optional

def _num(x) -> Optional[float]:
    try:
        if x is None or str(x).strip() == "":
            return None
        return float(x)
    except (ValueError, TypeError):
        return None

def sanitize_volume(largo, ancho, alto, volumen_original, tol=0.02):
    """Devuelve dict con volumen_calculado_m3, estado_volumen y auditoría.
    Estados: correcto | corregido | sin dimensiones | dimensiones invalidas
    """
    L, A, H = _num(largo), _num(ancho), _num(alto)
    V0 = _num(volumen_original)

    if None in (L, A, H) or L <= 0 or A <= 0 or H <= 0:
        return {
            "volumen_calculado_m3": None,
            "volumen_original_m3": V0,
            "estado_volumen": "sin dimensiones",
            "necesita_revision": True,
        }

    calc = round(L * A * H, 6)
    if V0 is None:
        estado = "corregido"
    elif V0 < 0:
        estado = "corregido"
    else:
        rel = abs(V0 - calc) / calc if calc else 1.0
        estado = "correcto" if rel <= tol else "corregido"

    return {
        "volumen_calculado_m3": calc,
        "volumen_original_m3": V0,
        "estado_volumen": estado,
        "necesita_revision": False,
    }
