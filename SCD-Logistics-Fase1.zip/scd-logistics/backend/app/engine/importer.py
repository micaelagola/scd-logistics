"""Importador flexible de Packing Lists / facturas (Excel/CSV/PDF).
Detecta la fila de encabezado y mapea columnas por sinónimos.
No inventa datos; lo que no reconoce va a 'errores'/'no_interpretadas'.
"""
import re
from .sku import normalize_sku, is_set

# sinónimos de encabezados -> campo canónico
SYNONYMS = {
    "sku": ["sku", "article #", "article", "item no", "item no.", "item", "art", "codigo", "code", "model"],
    "descripcion": ["description of goods", "description", "descripcion", "goods", "producto"],
    "cantidad": ["qty (pcs)", "qty", "quantity", "cantidad", "pcs", "total pcs"],
    "pcs_ctn": ["pcs/ctn", "pcs/set", "pcs per ctn", "pcs/pkg", "pieces /per pkg"],
    "ctn": ["ctn", "ctns", "cartons", "no of pkgs", "no of pkgs.", "bultos"],
    "largo": ["largo", "length", "l (cm)", "l"],
    "ancho": ["ancho", "width", "w (cm)", "w"],
    "alto": ["alto", "height", "h (cm)", "h"],
    "cbm": ["cbm", "volume", "volumen", "m3", "meas"],
    "peso_neto": ["nt.wt", "net weight", "n.w", "peso neto", "nt. wt.", "total(kgs) nt. wt."],
    "peso_bruto": ["gr.wt", "gross weight", "g.w", "peso bruto", "gr. wt.", "total(kgs) gr. wt."],
}

def _norm(s):
    return re.sub(r"\s+", " ", str(s or "").strip().lower())

def detect_header(rows, max_scan=25):
    """Busca la fila que contiene un encabezado tipo SKU + descripción."""
    best_idx, best_map, best_score = None, None, 0
    for i, row in enumerate(rows[:max_scan]):
        cells = [_norm(c) for c in row]
        mapping, score = {}, 0
        for canonical, syns in SYNONYMS.items():
            for j, cell in enumerate(cells):
                if cell in syns or any(cell == s for s in syns):
                    mapping[canonical] = j
                    score += 1
                    break
        if ("sku" in mapping or "descripcion" in mapping) and score > best_score:
            best_idx, best_map, best_score = i, mapping, score
    return best_idx, (best_map or {})

def _to_meters(v):
    """Heurística cm->m: valores > 3 se asumen cm (cajas reales < 3 m)."""
    try:
        x = float(v)
    except (ValueError, TypeError):
        return None
    if x <= 0:
        return None
    return round(x / 100.0, 6) if x > 3 else round(x, 6)

def parse_rows(rows, fuente="", archivo=""):
    """Devuelve (items, resumen). items = lista de dicts canónicos."""
    hidx, cmap = detect_header(rows)
    resumen = {"detectados": 0, "no_interpretadas": 0, "errores": []}
    items = []
    if hidx is None:
        resumen["errores"].append("No pude identificar la columna SKU.")
        return items, resumen
    for row in rows[hidx + 1:]:
        raw_sku = row[cmap["sku"]] if "sku" in cmap and cmap["sku"] < len(row) else None
        desc = row[cmap["descripcion"]] if "descripcion" in cmap and cmap["descripcion"] < len(row) else ""
        if (raw_sku is None or str(raw_sku).strip() == "") and (desc is None or str(desc).strip() == ""):
            continue
        if raw_sku is None or str(raw_sku).strip() == "":
            resumen["no_interpretadas"] += 1
            continue
        def g(key):
            return row[cmap[key]] if key in cmap and cmap[key] < len(row) else None
        item = {
            "sku": normalize_sku(raw_sku),
            "sku_original": str(raw_sku),
            "descripcion": str(desc or "").strip(),
            "cantidad": g("cantidad"),
            "ctn": g("ctn"),
            "largo_m": _to_meters(g("largo")),
            "ancho_m": _to_meters(g("ancho")),
            "alto_m": _to_meters(g("alto")),
            "cbm": g("cbm"),
            "peso_neto": g("peso_neto"),
            "peso_bruto": g("peso_bruto"),
            "tipo": "set" if is_set(raw_sku, desc) else "normal",
            "fuente": fuente,
            "archivo_origen": archivo,
        }
        items.append(item)
        resumen["detectados"] += 1
    return items, resumen


# ---- Fallback PDF por texto (packing lists sin tabla con líneas) ----
_ITEM_LINE = re.compile(
    r"^(?P<ctnrange>\d+\s*-\s*\d+)\s+(?P<sku>[A-Za-z0-9][A-Za-z0-9\-\+/]*)\s+"
    r"(?P<a>[\d.,]+)\s+(?P<b>[\d.,]+)\s+(?P<c>[\d.,]+)\s+(?P<pcs>[\d.,]+)\s+"
    r"(?P<unit>[A-Za-z]+)\s+(?P<d>[\d.,]+)\s+(?P<e>[\d.,]+)"
)

def parse_pdf_text(text, fuente="", archivo=""):
    """Extrae items de un PL en PDF sin tabla, línea por línea.
    Formato tipo Victor Forgings: '<rango ctn> <SKU> ... <PCS> <UNIT> ...'.
    """
    items, resumen = [], {"detectados": 0, "no_interpretadas": 0, "errores": []}
    for line in text.splitlines():
        m = _ITEM_LINE.match(line.strip())
        if not m:
            continue
        raw_sku = m.group("sku")
        def f(x):
            try: return float(str(x).replace(",", ""))
            except (ValueError, TypeError): return None
        items.append({
            "sku": normalize_sku(raw_sku), "sku_original": raw_sku,
            "descripcion": "", "cantidad": f(m.group("pcs")),
            "ctn": m.group("ctnrange").replace(" ", ""),
            "largo_m": None, "ancho_m": None, "alto_m": None, "cbm": None,
            "peso_neto": f(m.group("d")), "peso_bruto": f(m.group("e")),
            "tipo": "set" if is_set(raw_sku, "") else "normal",
            "fuente": fuente, "archivo_origen": archivo,
        })
        resumen["detectados"] += 1
    if not items:
        resumen["errores"].append("No pude identificar filas de productos en el PDF.")
    return items, resumen
