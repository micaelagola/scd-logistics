"""Regla EXACTA de SKU (SCD Logistics).
Única transformación permitida: si empieza con 'WT-' (exacto, mayúsculas),
eliminar solo ese prefijo. Nada más se altera.
"""
WT_PREFIX = "WT-"

def normalize_sku(raw: str) -> str:
    if raw is None:
        return ""
    s = str(raw).strip()            # solo recorta espacios de los extremos
    if s.startswith(WT_PREFIX):     # prefijo exacto, case-sensitive
        return s[len(WT_PREFIX):]
    return s                        # se conserva TAL CUAL (guiones, +, /, saltos)

def is_set(raw_sku: str, descripcion: str = "") -> bool:
    """Set = varios componentes unidos. Señales robustas (no confundir con
    sufijos de modelo tipo 'UT202A+' o productos como 'TAP AND DIE SET')."""
    raw = str(raw_sku or "")
    sku = normalize_sku(raw)
    if "\n" in raw:
        return True
    if " + " in sku:                # 'CHD65-BL + SBS22'
        return True
    if "in one set" in str(descripcion).lower():
        return True
    return False
