"""Acceso a Postgres/Supabase vía DATABASE_URL (server-side only).
Las credenciales viven en variables de entorno, NUNCA en el frontend.
"""
import os, json
import psycopg
from psycopg.rows import dict_row

def _conn():
    url = os.environ.get("DATABASE_URL")
    if not url:
        raise RuntimeError("Falta DATABASE_URL")
    return psycopg.connect(url, row_factory=dict_row)

def list_productos(q=None):
    sql = "select * from productos"
    args = []
    if q:
        sql += " where sku ilike %s or descripcion ilike %s"
        args = [f"%{q}%", f"%{q}%"]
    sql += " order by sku"
    with _conn() as c, c.cursor() as cur:
        cur.execute(sql, args); return cur.fetchall()

def get_by_skus(skus):
    if not skus: return {}
    with _conn() as c, c.cursor() as cur:
        cur.execute("select * from productos where sku = any(%s)", [list(skus)])
        return {r["sku"]: r for r in cur.fetchall()}

def upsert_producto(p, motivo="import"):
    cols = ("sku","descripcion","largo_m","ancho_m","alto_m","volumen_calculado_m3",
            "volumen_original_m3","estado_volumen","tipo","peso_neto","peso_bruto",
            "fuente","archivo_origen","fecha_recalculo")
    vals = [p.get(k) for k in cols]
    ph = ",".join(["%s"]*len(cols))
    up = ",".join([f"{k}=excluded.{k}" for k in cols if k!="sku"])
    with _conn() as c, c.cursor() as cur:
        cur.execute(
            f"insert into productos ({','.join(cols)}) values ({ph}) "
            f"on conflict (sku) do update set {up}, version=productos.version+1 returning id", vals)
        return cur.fetchone()["id"]

def registrar_importacion(nombre, tipo, resumen, storage_path=None, proveedor=None):
    with _conn() as c, c.cursor() as cur:
        cur.execute("insert into importaciones (nombre_archivo,tipo,storage_path,proveedor,resumen_json) "
                    "values (%s,%s,%s,%s,%s) returning id",
                    [nombre,tipo,storage_path,proveedor,json.dumps(resumen)])
        return cur.fetchone()["id"]

def crear_revision(sku, imp_id, actuales, nuevos, motivo):
    with _conn() as c, c.cursor() as cur:
        cur.execute("insert into revision_pendiente (sku,importacion_id,valores_actuales_json,"
                    "valores_nuevos_json,motivo) values (%s,%s,%s,%s,%s)",
                    [sku,imp_id,json.dumps(actuales),json.dumps(nuevos),motivo])

def list_revisiones():
    with _conn() as c, c.cursor() as cur:
        cur.execute("select * from revision_pendiente where estado='abierta' order by fecha")
        return cur.fetchall()
