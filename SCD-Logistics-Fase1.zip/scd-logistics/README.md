# SCD Logistics — Fase 1 (Maestro de dimensiones)

Aplicación **web** para mantener la base única de productos y medidas de embalaje,
importar packing lists (PDF/Excel/CSV), aplicar la regla exacta de SKU, detectar
duplicados y llevar bandeja de revisión + auditoría.

## Arquitectura
- **Frontend:** Next.js (React) → Vercel. Solo consume la API, no guarda secretos.
- **Backend:** FastAPI (Python) → Render. Lee PDF/Excel, sanea, deduplica.
- **Base:** PostgreSQL → Supabase (fuente maestra viva).
- **Archivos:** Supabase Storage (originales inmutables).

Regla de SKU: si empieza EXACTO con `WT-`, se elimina solo ese prefijo. Nada más.
Sets (`CHD65-BL + SBS22`, `CHT15-BL / CCS6-BL / In one set`) se conservan tal cual,
con `tipo=set`. Los volúmenes se recalculan `L×A×H` (6 decimales); el histórico no se confía.

## Deploy (una sola vez, sin tocar código)
1. **Supabase** → crear proyecto → SQL Editor → pegar `db/schema.sql` → Run.
2. **Render** → New Web Service → conectar este repo, carpeta `backend/` →
   variables `DATABASE_URL` (de Supabase) y `FRONTEND_ORIGIN`. Deploy.
3. **Cargar maestro:** en Render Shell → `python seed_master.py data/master_PL_SANEADO.csv`
   (o correrlo local con `DATABASE_URL` apuntando a Supabase).
4. **Vercel** → Import Project, carpeta `frontend/` → variable
   `NEXT_PUBLIC_API_URL` (URL de Render). Deploy. Ese es tu link público.

## Correr local (opcional)
- Backend: `cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload`
- Frontend: `cd frontend && npm install && npm run dev` → http://localhost:3000

## Tests
`cd backend && python tests/test_engine.py`  → 4/4 (regla SKU, sets, volumen, dedup).

## Seguridad
Credenciales solo en variables de entorno del backend. El link es público sin login
en v1; la arquitectura ya tiene tabla `usuarios` + RLS lista para activar auth.
