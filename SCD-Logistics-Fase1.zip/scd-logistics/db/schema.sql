-- SCD Logistics — esquema Postgres/Supabase (Fase 1)
-- Fuente maestra viva. Preparado para sumar login/RLS luego sin rehacer.

create table if not exists productos (
  id                    bigserial primary key,
  sku                   text unique not null,          -- clave lógica (ya sin WT-)
  descripcion           text,
  largo_m               numeric,
  ancho_m               numeric,
  alto_m                numeric,
  volumen_calculado_m3  numeric,
  volumen_original_m3   numeric,
  estado_volumen        text check (estado_volumen in
                         ('correcto','corregido','sin dimensiones','dimensiones invalidas','pendiente de revision')),
  tipo                  text default 'normal' check (tipo in ('normal','set')),
  peso_neto             numeric,
  peso_bruto            numeric,
  fuente                text,
  archivo_origen        text,
  fecha_actualizacion   date default current_date,
  fecha_recalculo       date,
  version               integer default 1              -- bloqueo optimista
);

create table if not exists importaciones (
  id            bigserial primary key,
  nombre_archivo text not null,
  tipo          text,                                  -- pdf|xlsx|csv
  storage_path  text,
  proveedor     text,
  fecha         timestamptz default now(),
  resumen_json  jsonb
);

create table if not exists revision_pendiente (
  id                bigserial primary key,
  sku               text not null,
  importacion_id    bigint references importaciones(id),
  valores_actuales_json jsonb,
  valores_nuevos_json   jsonb,
  motivo            text,
  estado            text default 'abierta' check (estado in ('abierta','resuelta')),
  decision          text check (decision in ('mantener','actualizar','variante')),
  fecha             timestamptz default now()
);

create table if not exists auditoria (
  id            bigserial primary key,
  producto_id   bigint references productos(id),
  sku           text,
  campo         text,
  valor_anterior text,
  valor_nuevo   text,
  motivo        text,
  usuario       text,                                  -- null en v1
  fecha         timestamptz default now()
);

-- Preparadas para fases 2-4 (inactivas ahora): usuarios, contenedores,
-- optimizaciones, despachos, despacho_items.
create table if not exists usuarios (
  id bigserial primary key, email text unique, rol text default 'viewer', creado timestamptz default now()
);
